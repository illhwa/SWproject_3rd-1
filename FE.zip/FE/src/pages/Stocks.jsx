function Stocks() {
    return (
      <div>
        <h2>주식 추천 페이지</h2>
      </div>
    )
  }
  export default Stocks
  