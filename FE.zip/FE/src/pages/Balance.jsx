function Balance() {
    return (
      <div>
        <h2>잔액 확인</h2>
        {/* 추후 이메일/비밀번호 입력 및 API 연동 */}
      </div>
    )
  }
  export default Balance
  