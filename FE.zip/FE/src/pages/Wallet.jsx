
  function Wallet() {
    return (
      <div>
        <h2>지갑 등록</h2>
      </div>
    );
  }
  
  export default Wallet;
  